# AlexaPi Windows 

# NOW WORKING!!!

## Dependencies

* [Python](https://www.python.org/downloads/windows/) (tested with 3.6, needs pip)
* [Visual C++ 2015 Build Tools](http://landinghub.visualstudio.com/visual-cpp-build-tools)
* _Swig_ (Installed with **AlexaPi-Windows**)
* [VLC](http://www.videolan.org/vlc/download-windows.html)

## How to install

See [here](https://github.com/alexa-pi/AlexaPi-Windows/wiki/Installing)

## Original project: https://github.com/alexa-pi/AlexaPi

