# Contributing guide

See [here](https://github.com/alexa-pi/AlexaPi/blob/master/CONTRIBUTING.md)